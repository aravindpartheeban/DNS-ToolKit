DNS Toolkit
Version 1.0.0

A Windows tool to benchmark and switch DNS providers
for speed, privacy, and security.

This app does not collect or send any data.
Admin permissions are required only to change DNS.

Created by Aravind Partheeban.
